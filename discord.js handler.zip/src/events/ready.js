const mongoose = require('mongoose');
const { ActivityType } = require('discord.js');

module.exports = {
    name: 'ready',
    async execute(client) {
        console.log(`Logged in as ${client.user.tag}!`);
  const mongodbURL = process.env.MONGODB_URL; 

        if (mongodbURL) {
            try {
                await mongoose.connect(mongodbURL); 
                console.log("Database has successfully connected!");
            } catch (error) {
                console.error('database connection error:', error);
            }
        } else {
            console.warn('\x1b[31m%s\x1b[0m', 'MongoDB connection URL not found in .env');
        }
        
        await client.user.setPresence({
            activities: [{ name: 'This handler is fire', type: ActivityType.Custom }],
            status: 'Online', 
        });
    },
};
