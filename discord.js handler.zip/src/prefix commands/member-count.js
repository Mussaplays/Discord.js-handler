const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'mc',
    description: 'Displays the server member count and bot count.',
    execute(message, args) {
        
        message.delete();

       
        const totalMembers = message.guild.memberCount;
        const botCount = message.guild.members.cache.filter(member => member.user.bot).size;

       
        const embed = new EmbedBuilder()
           .setDescription(`Total Members: ${totalMembers}\nBot Count ${botCount} `)
            .setColor('#2B2D31')
           

      
        message.channel.send({ embeds: [embed] });
    },
};
