module.exports = {
    name: 'ping',
    description: 'Responds with Pong! Shows latency in ms.',
    async execute(message, args) {
        const latency = message.client.ws.ping;
        await message.reply(`Pong! Latency: ${latency}ms`);
    },
};
