const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder } = require('discord.js');
const { connect } = require('mongoose');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('membercount')
    .setDescription('Displays the member count and bot count in the server'),
  async execute(interaction) {
    try {
      const { guild } = interaction;

      const totalMembers = guild.memberCount; 
      const botCount = guild.members.cache.filter(member => member.user.bot).size;
      const embed = new EmbedBuilder()
        .setColor('#2B2D31')
       .setDescription(`Total Members: ${totalMembers}\nBot Count: ${botCount}`);

      await interaction.reply({ embeds: [embed] });
    } catch (error) {
   
    }
  },
};
