const fs = require('fs');

module.exports = (client) => {
    client.handleEvents = (eventFiles, path) => {
        let loadedCount = 0;

        for (const file of eventFiles) {
            const filePath = `${path}/${file}`; 

            try {
                const event = require(`../events/${file}`);
                const eventName = file.split(".")[0];

                if (event.once) {
                    client.once(eventName, (...args) => event.execute(...args, client));
                } else {
                    client.on(eventName, (...args) => event.execute(...args, client));
                }

                if (fs.statSync(filePath).size === 0) {
                    console.warn(`\x1b[31mWarning: Event file ${file} is empty.\x1b[0m`); 
                    continue; 
                }

                loadedCount++;
            } catch (error) {
                console.error(`Error loading event ${file}: ${error.message}`);
            }
        }

        console.log(`Loaded ${loadedCount} events.`);
    };
};
