const fs = require('fs');
const path = require('path');

const prefixes = ['!', '-', '$'];

const commandFiles = fs.readdirSync(path.join(__dirname, '../prefix commands')).filter(file => file.endsWith('.js'));
const commands = Object.create(null);

for (const file of commandFiles) {
    const filePath = path.join(__dirname, '../prefix commands', file);
    const command = require(filePath);

    if (fs.statSync(filePath).size === 0) {
        console.warn(`\x1b[31mWarning: Prefix command file "${file}" is empty.\x1b[0m`);
    } else {
        commands[command.name] = command;
    }
}

console.log(`Loaded ${Object.keys(commands).length} prefix commands.`);

module.exports = (client) => {
    client.on('messageCreate', async (message) => {
        if (message.author.bot) return;
        if (!message.guild) return;

        const prefix = prefixes.find(p => message.content.startsWith(p));
        if (!prefix) return;

        const args = message.content.slice(prefix.length).trim().split(/ +/);
        const commandName = args.shift().toLowerCase();

        const command = commands[commandName];
        if (command) {
            try {
                await command.execute(message, args);
            } catch (error) {
                console.error(`Error executing command "${commandName}":`, error);
                await message.reply('There was an error executing that command.');
            }
        }
    });
};
