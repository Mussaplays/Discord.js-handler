const { REST } = require("@discordjs/rest");
const { Routes } = require('discord-api-types/v9');
const fs = require('fs');

const clientId = '  YOUR BOT ID';
const guildId = 'YOUR SERVER ID';  

module.exports = (client) => {
    client.handleCommands = async (commandFolders, path) => {
        client.commandArray = [];
        const successCommands = [];
        const failedCommands = [];

        for (const folder of commandFolders) {
            const commandFiles = fs.readdirSync(`${path}/${folder}`).filter(file => file.endsWith('.js'));

            for (const file of commandFiles) {
                try {
                    const command = require(`../commands/${folder}/${file}`);
                    
                 
                    if (!command.data || !command.data.name) {
                        failedCommands.push(file);
                        continue; 
                    }

               
                    client.commands.set(command.data.name, command);
                    client.commandArray.push(command.data.toJSON());
                    successCommands.push(command.data.name);
                    
                } catch (error) {
                    failedCommands.push(file);
                }
            }
        }

        console.log(`loaded ${successCommands.length} slash commands.`);
        if (failedCommands.length > 0) {
            console.error(`Failed to load ${failedCommands.length} command: ${failedCommands.join(', ')}`);
        }

  
        const rest = new REST({ version: '9' }).setToken(process.env.token);

        try {
            await rest.put(
                Routes.applicationGuildCommands(clientId, guildId),
                { body: client.commandArray },
            );
          
        } catch (error) {
            console.error(`Error registering commands: ${error.message}`);
        }
    };

}